<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
</head>
<body>
    <section>
        <h1>Maintenance Management System for Industrial Equipment</h1>
        <header>
            <nav>
                <a href="index.php">Home</a>
                <a href="nosotros.php">Nosotros</a>
                <a href="">Anuncios</a>
                <a href="blog.php">Blog</a>
                <a href="contacto.php">Contacto</a>
            </nav>
        </header>
        <h2>Maintenance Management System for Industrial Equipment</h2>
    </section>