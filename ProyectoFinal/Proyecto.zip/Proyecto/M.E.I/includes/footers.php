<section>
        <footer>
        <nav>
                <a href="index.php">Home</a>
                <a href="nosotros.php">Nosotros</a>
                <a href="">Anuncios</a>
                <a href="blog.php">Blog</a>
                <a href="contacto.php">Contacto</a>
            </nav>  
            <p>Todos los derechos reservados by: yo</p>
        </footer>
    </section>
</body>
</html>